$(function() {
	$(".link-pay").click(function() {
		location.href = "payment.html";
	})
})
$(function() {
	$(".link-success").click(function() {
		location.href = "paySuccess.html";
	})
})