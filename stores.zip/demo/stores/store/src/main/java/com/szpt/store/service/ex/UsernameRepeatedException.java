package com.szpt.store.service.ex;

/**
 * 用户名被占用异常
 */
public class UsernameRepeatedException extends ServiceExceptions{
    public UsernameRepeatedException() {
        super();
    }

    public UsernameRepeatedException(String message) {
        super(message);
    }

    public UsernameRepeatedException(String message, Throwable cause) {
        super(message, cause);
    }

    public UsernameRepeatedException(Throwable cause) {
        super(cause);
    }

    protected UsernameRepeatedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
