package com.szpt.store.mapper;

import com.szpt.store.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

/**
 * 设计接口和抽象方法
 */
public interface UserMapper {

    /**
     * 注册
     * @param user
     * @return
     */
    Integer insert(User user);

    /**
     * 查询
     * @param username 根据用户名查询数据
     * @return
     */
    User findByUsername(String username);


    /**
     * 修改密码
     * @param password
     * @param uid
     * @param modifiedUser
     * @param modifiedTime
     * @return
     */
    Integer updateByPassword(
                             Integer uid,
                             String password,
                             String modifiedUser,
                             Date modifiedTime);

    /**
     * 根据uid查询
     * @param uid
     * @return
     */
    User findUserByUid(Integer uid);


    /**
     * 修改个人资料
     * @param user
     * @return
     */
    Integer updatePersonalData(User user);

    /**
     * 修改头像
     * @param uid
     * @param avatar
     * @param modifiedUser
     * @param modifiedTime
     * @return
     */
    Integer updateAvatar(
            @Param("uid") Integer uid,
            @Param("avatar") String avatar,
            @Param("modifiedUser") String modifiedUser,
            @Param("modifiedTime") Date modifiedTime);

}