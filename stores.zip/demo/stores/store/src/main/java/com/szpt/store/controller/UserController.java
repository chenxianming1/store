package com.szpt.store.controller;


import com.szpt.store.controller.ex.*;
import com.szpt.store.entity.User;
import com.szpt.store.service.UserService;
import com.szpt.store.service.ex.InsertException;
import com.szpt.store.service.ex.UsernameRepeatedException;
import com.szpt.store.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@RestController
@RequestMapping("users/")
public class UserController extends BaseController{
    @Autowired
    private UserService userService;

//    @RequestMapping("reg")
//    public JsonResult<Void> reg(User user){
//        JsonResult<Void> result = new JsonResult<>();
//        try {
//            userService.reg(user);
//            result.setState(200);
//            result.setMessage("注册成功");
//        } catch (UsernameRepeatedException e) {
//            result.setState(4000);
//            result.setMessage("用户名被占用");
//        }catch (InsertException e) {
//            result.setState(5000);
//            result.setMessage("注册时候产生未知异常");
//        }
//        return result;
//    }

    @RequestMapping("reg")
    public JsonResult<Void> reg(User user){
        userService.reg(user);
        return new JsonResult<Void>(OK);
    }

    @RequestMapping("login")
    public JsonResult<User> login(String username, String password, HttpSession session){
        User user = userService.login(username, password);
        //向session对象中完成数据的绑定（session全局的）
        session.setAttribute("uid",user.getUid());
        session.setAttribute("username",user.getUsername());
        //获取session中绑定的数据
        System.out.println(getUserIdFromSession(session));
        System.out.println(getUsernameFromSession(session));
        return new JsonResult<User>(OK,user);
    }

    @RequestMapping("change_password")
    public JsonResult<Void> updatePassword(String oldPassword,String newPassword,HttpSession session){
        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);
        userService.UpdatePassword(uid,username,oldPassword,newPassword);
        return new JsonResult<Void>(OK);


    }

    @RequestMapping("get_uid")
    public JsonResult<User> queryByUid(HttpSession session){

        Integer uid = getUserIdFromSession(session);
        User result = userService.queryByUid(uid);
        return new JsonResult<>(OK,result);
    }

    @RequestMapping("change_personal_data")
    public JsonResult<Void> updatePersonalData(User user,HttpSession session){
        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);
        userService.updatePersonalData(uid,username,user);
        return new JsonResult<>(OK);
    }


    public static final int AVATAR_MAX_SIZE = 10 * 1024 *1024;
    public static final List<String> AVATAR_TYPES = new ArrayList<String>();

    static {
        AVATAR_TYPES.add("image/jpeg");
        AVATAR_TYPES.add("image/png");
        AVATAR_TYPES.add("image/bmp");
        AVATAR_TYPES.add("image/gif");

    }

    @RequestMapping("changeAvatar")
    public JsonResult<String> changeAvatar(@RequestParam("file") MultipartFile file,
                                           HttpSession session){
        if (file.isEmpty()){
            throw new FileEmptyException("文件上传不允许为空");
        }
        if (file.getSize() > AVATAR_MAX_SIZE){
            throw new FileSizeException("文件超出限制");
        }
        //判断文件类型是否为我们规定的的后缀类型
        String contentType = file.getContentType();
        if (!AVATAR_TYPES.contains(contentType)){
            throw new FileTypeException("不支持使用该类型的文件作为头像");
        }
        // 获取当前项目的绝对磁盘路径
        String parent = session.getServletContext().getRealPath("upload");
        // File对象指向这个路径
        File dir = new File(parent);
        if (!dir.exists()) {//
            dir.mkdirs();
        }
        //获得这个文件名称，uuid工具来生成一个新的字符串作为文件名
        String originalFilename = file.getOriginalFilename();
        System.out.println("originalFilename="+originalFilename);
        int index = originalFilename.lastIndexOf(".");
        String suffix = originalFilename.substring(index);
        String filename = UUID.randomUUID().toString().toUpperCase() + suffix;
        File dest = new File(dir,filename);
        try {
            file.transferTo(dest);
        } catch (FileStateException e){
            throw new FileStateException("文件状态异常");

        }catch (IOException e) {
           throw new FileUploadIOException("文件读写异常");
        }


        // 从Session中获取uid和username
        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);

        // 头像路径
        String avatar = "/upload/" + filename;

        // 将头像写入到数据库中
        userService.ChangeAvatar(uid,avatar,username);

        // 返回成功头像路径
        return new JsonResult<>(OK, avatar);
    }

}
