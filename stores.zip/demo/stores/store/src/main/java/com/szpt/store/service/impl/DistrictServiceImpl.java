package com.szpt.store.service.impl;

import com.szpt.store.entity.District;
import com.szpt.store.mapper.DistrictMapper;
import com.szpt.store.mapper.UserMapper;
import com.szpt.store.service.DistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DistrictServiceImpl implements DistrictService {

    @Autowired
    private DistrictMapper districtMapper;

    @Override
    public List<District> getByParent(String parent) {


        List<District> result = districtMapper.findByParent(parent);
        for (District d : result) {
            d.setId(null);
            d.setParent(null);
        }
        return result;
    }

    @Override
    public String getNameByCode(String code) {


        return districtMapper.findNameByCode(code);
    }


}
