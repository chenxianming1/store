package com.szpt.store.mapper;

import com.szpt.store.entity.Address;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface AddressMapper {
    /**
     * 添加收获地址
     * @param address
     * @return
     */
    Integer insertAddress(Address address);

    /**
     * 查询收货地址数量
     * @param uid
     * @return
     */
    Integer countByUid(Integer uid);


    /**
     * 通过uid展示用户的收货地址列表
     * @param uid
     * @return
     */
    List<Address> findByUid(Integer uid);

    /**
     * 设置没有默认收货地址
     * @param uid
     * @return
     */
    Integer updateNonDefaultByUid(Integer uid);


    /**
     * 设置默认收货地址
     * @param
     * @return
     */
    Integer updateDefaultByAid(@Param("aid") Integer aid,
                               @Param("modifiedUser") String modifiedUser,
                               @Param("modifiedTime") Date modifiedTime);;



    Address findByAid(Integer aid);

    /**
     * 根据收货地址id删除数据
     * @param aid 收货地址id
     * @return 受影响的行数
     */
    Integer deleteByAid(Integer aid);


    /**
     * 查询某用户最后修改的收货地址
     * @param uid
     * @return
     */
    Address findLastModified(Integer uid);
}
