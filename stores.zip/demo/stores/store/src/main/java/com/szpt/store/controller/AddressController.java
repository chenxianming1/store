package com.szpt.store.controller;


import com.szpt.store.entity.Address;
import com.szpt.store.service.AddressService;
import com.szpt.store.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;


@RestController
@RequestMapping("address/")
public class AddressController extends BaseController{
    @Autowired
    private AddressService addressService;


    @RequestMapping("add_new_address")
    public JsonResult<Void> address_newAddress(HttpSession session, Address address){
        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);
        addressService.addNewAddress(uid,username,address);
        return new JsonResult<Void>(OK);
    }

    @RequestMapping("show")
    public JsonResult <List<Address>> getByUid(HttpSession session) {
        Integer uid = getUserIdFromSession(session);
        List <Address> data = addressService.getByUid(uid);
        return new JsonResult<>(OK, data);
    }
    @RequestMapping("{aid}/set_default")
    public JsonResult<Void> setDefault(@PathVariable("aid") Integer aid, HttpSession session){

        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);
        addressService.setDefault(aid, uid, username);
        return new JsonResult<>(OK);
    }

    @RequestMapping("{aid}/delete")
    public JsonResult<Void> delete(@PathVariable("aid") Integer aid, HttpSession session) {
        Integer uid = getUserIdFromSession(session);
        String username = getUsernameFromSession(session);
        addressService.delete(aid, uid, username);
        return new JsonResult<>(OK);
    }
}
