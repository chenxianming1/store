package com.szpt.store.service;

import com.szpt.store.entity.User;

/**用户模块业务层接口*/
public interface UserService {

    /**
     * 用户注册方法
     * @param user
     */
    void reg(User user);


    /**
     *用户登录方法
     * @param username
     * @param password
     * @return
     */

    User login(String username,String password);

    /**
     * 修改密码
     * @param uid
     * @param username
     * @param oldPassword
     * @param newPassword
     */
    void UpdatePassword(Integer uid,String username,String oldPassword,String newPassword);


    /**
     * 根据uid查询
     * @param uid
     * @return
     */
    User queryByUid(Integer uid);


    /**
     * 修改
     * @param uid
     * @param username
     * @param user
     */
    void updatePersonalData(Integer uid,String username,User user);

    /**
     * 更改头像
     * @param uid
     * @param avatar
     * @param username
     */
    void ChangeAvatar(Integer uid,String avatar,String username);




}
