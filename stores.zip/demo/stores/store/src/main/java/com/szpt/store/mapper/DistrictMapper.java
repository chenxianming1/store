package com.szpt.store.mapper;


import com.szpt.store.entity.District;

import java.util.List;

public interface DistrictMapper {

    /**
     * 通过parent来查询省市区
     * @param parent
     * @return
     */
    List<District> findByParent(String parent);

    String findNameByCode (String code);
}
