package com.szpt.store.mapper;


import com.szpt.store.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UserMapperTests {
    @Autowired
    private UserMapper userMapper;
    @Test
    public void insert(){
        User user = new User();
        user.setUsername("xiao8");
        user.setPassword("12345");
        Integer rows = userMapper.insert(user);
        System.out.println(rows);
    }
    @Test
    public void findByUsername(){
        User user = userMapper.findByUsername("xiao6");
        System.out.println(user);
    }




    @Test
    public void updateByPassword(){

        Integer uid= 19;
        String password = "123456";
        String modifiedUser = "超级管理员";
        Date modifiedTime = new Date();

        Integer rows = userMapper.updateByPassword(uid, password, modifiedUser, modifiedTime);
        System.out.println("rows="+rows);
    }


    @Test
    public void findUserByUid(){
        Integer uid = 19;
        User result = userMapper.findUserByUid(uid);
        System.out.println(result);
    }

    @Test
    public void updatePersonalData(){
        User user = new User();
        user.setUid(23);
        user.setPhone("123456789");
        user.setEmail("1562090524@qq.com");
        user.setGender(1);
        user.setModifiedUser("李易峰");
        user.setModifiedTime(new Date());
        Integer rows = userMapper.updatePersonalData(user);
        System.out.println(rows);
    }

    @Test
    public void updateAvatar(){
        Integer uid = 23;
        String avatar = "/upload/avatar.png";
        String modifiedUser = "周杰轮3";
        Date modifiedTime = new Date();
        Integer rows = userMapper.updateAvatar(uid, avatar, modifiedUser, modifiedTime);
        System.out.println("rows=" + rows);
    }

}