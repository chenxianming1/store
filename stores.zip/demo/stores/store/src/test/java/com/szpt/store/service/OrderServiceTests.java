package com.szpt.store.service;


import com.szpt.store.entity.Order;
import com.szpt.store.service.OrderService;
import com.szpt.store.service.ex.ServiceExceptions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderServiceTests {


    @Autowired
    private OrderService orderService;

    @Test
    public void create() {
        try {
            Integer aid = 9;
            Integer[] cids = {4, 5, 6,};
            Integer uid = 24;
            String username = "订单管理员";
            Order order = orderService.create(aid, cids, uid, username);
            System.out.println(order);
        } catch (ServiceExceptions e) {
            System.out.println(e.getClass().getSimpleName());
            System.out.println(e.getMessage());
        }
    }
}
