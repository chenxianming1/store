package com.szpt.store.service;


import com.szpt.store.entity.User;
import com.szpt.store.mapper.UserMapper;
import com.szpt.store.service.ex.ServiceExceptions;
import com.szpt.store.service.ex.UpdateException;
import com.szpt.store.service.ex.UserNotFindException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.Date;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UserServiceTests {
    @Autowired
    private UserService userService;

//    @Test
//    public void reg() {
//        try {
//            User user = new User();
//            user.setUsername("lisi");
//            user.setPassword("123");
//            userService.reg(user);
//            System.out.println("OK");
//        } catch (ServiceExceptions e) {
//
//            System.out.println(e.getClass().getSimpleName());
//            System.out.println(e.getMessage());
//        }
//
//    }

    @Test
    public void login() {
        try {
            String username = "xiao9";
            String password = "12345";
            User user = userService.login(username, password);
            System.out.println("登录成功！" + user);
        } catch (ServiceExceptions e) {
            System.out.println("登录失败！" + e.getClass().getSimpleName());
            System.out.println(e.getMessage());
        }
    }


    @Test
    public void changePassword(){
        userService.UpdatePassword(22,"超级管理员","123","321");
    }


    @Test
    public void queryByUid() {
        User result = userService.queryByUid(23);
        System.out.println(result);
    }

    @Test
    public void updatePersonalData() {

        User user = new User();
        user.setPhone("13750302170");
        user.setEmail("123@qq.com");
        user.setGender(0);

        userService.updatePersonalData(23,"管理员",user);
        }
    @Test
    public void ChangeAvatar(){
        Integer uid = 23;
        String avatar = "/upload/111.png";
        String username = "小明";
        userService.ChangeAvatar(uid,avatar,username);
        System.out.println("OK");

    }

}
