package com.szpt.store.mapper;

import com.szpt.store.entity.Address;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class AddressMapperTests {

    @Autowired
    private AddressMapper addressMapper;


    @Test
    public void insertAddress(){
        Address address = new Address();
        address.setUid(1);
        address.setName("admin");
        address.setPhone("17858802974");
        address.setAddress("雁塔区小寨赛格");
        Integer rows = addressMapper.insertAddress(address);
        System.out.println(rows);
    }

    @Test
    public void countByUid(){
        Integer count = addressMapper.countByUid(1);
        System.out.println(count);
    }

    @Test
    public void findByUid() {
        Integer uid = 24;
        List<Address> list = addressMapper.findByUid(uid);
        System.out.println("count=" + list.size());
        for (Address item : list) {
            System.out.println(item);
        }
    }

    @Test
    public void updateNonDefaultByUid() {
        Integer uid = 24;
        Integer rows = addressMapper.updateNonDefaultByUid(uid);
        System.out.println("rows=" + rows);
    }


    @Test
    public void updateDefaultByAid() {
        Integer aid = 6;
        String modifiedUser = "管理员";
        Date modifiedTime = new Date();
        Integer rows = addressMapper.updateDefaultByAid(aid, modifiedUser, modifiedTime);
        System.out.println("rows=" + rows);
    }


    @Test
    public void findByAid() {
        Integer aid = 6;
        Address result = addressMapper.findByAid(aid);
        System.out.println(result);
    }


    @Test
    public void deleteByAid() {
        Integer aid = 1;
        Integer rows = addressMapper.deleteByAid(aid);
        System.out.println("rows=" + rows);
    }


    @Test
    public void findLastModified() {
        Integer uid = 24;
        Address result = addressMapper.findLastModified(uid);
        System.out.println(result);
    }


}
